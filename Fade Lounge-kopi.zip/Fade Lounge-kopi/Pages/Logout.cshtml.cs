using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages
{
    public class LogoutModel : PageModel
    {
        private IAdminRepository _adminRepository;

        public LogoutModel(IAdminRepository adminRepository)
        {
            _adminRepository = adminRepository;
        }

        public IActionResult OnGet()
        {
            _adminRepository.LogoutKundeAdm();

            return RedirectToPage("Index");
        }
    }
}
