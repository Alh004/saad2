using Fade_Lounge.Model;
using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.admin;


public class RemoveKundeAdmin : PageModel
{
    private IAdminRepository _repo;
    
    public RemoveKundeAdmin(IAdminRepository repo)
    {
        _repo = repo;
    }



    public Admin admin { get; private set; }
        

    public IActionResult OnGet(int KundeNummer)

    {
        admin= _repo.RemoveKundeAdm(KundeNummer);


        return Page();
    }

    public IActionResult OnPostDelete(int KundeNummer)
    {
        _repo.RemoveKundeAdm(KundeNummer);

        return RedirectToPage("Index");
    }

    public IActionResult OnPostCancel()
    {
        return RedirectToPage("Index");
    }



}