using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages.Kunder;

public class IndexKunder : PageModel
{
    public void OnGet()
    {
        
    }
}