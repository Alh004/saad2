using Fade_Lounge.ServicAs;
using Fade_Lounge.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Fade_Lounge.Pages;

public class Loginmodel : PageModel
{
    
    private IAdminRepository _adminRepository;

    public Loginmodel(IAdminRepository adminRepository)
    {
        adminRepository = adminRepository;
    }



    [BindProperty]
    public string Email { get; set; }

    [BindProperty]
    public string Adgangskode { get; set; }

    public void OnGet()
    {
    }
    public IActionResult OnPost()
    {
        if (Email == null || Adgangskode == null)
        {
            return Page();
        }

        if (!_adminRepository.CheckKundeAdm(Email, Adgangskode))
        {
            return Page();
        }

        return RedirectToPage("Index");
    }
}
    
