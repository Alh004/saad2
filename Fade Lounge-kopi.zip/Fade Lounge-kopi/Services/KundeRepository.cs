using Fade_Lounge.Model;

namespace Fade_Lounge.Services
{
    public class KundeRepository : IKundeRepository
    {
        private List<Kunde> _Kunder = new List<Kunde>();
    
        public Kunde? KundeLoggedIn { get; private set; }

        public KundeRepository(bool mockData = false)

        {
            if (mockData)
            {
                // Make sure to use unique keys for each Kunde
                _Kunder.Add(new Kunde(1, "saad", "42546563", "hsfh@live.dk", "2000", false));
                _Kunder.Add(new Kunde(2, "saaad", "98234576", "yhbh@gmail.com", "2450", true));
                _Kunder.Add( new Kunde(3, "ødelagt i fort 16-0", "12456587", "peop@outlook.gb", "4312", false));
            }
        }

        public void AddKunde(Kunde kunde)
        {
            _Kunder.Add(kunde);
        }

        public bool CheckKunde(string email, string adgangskode)
        {
            Kunde? foundUser = _Kunder.Find(u => u.Email == email && u.Adgangskode == adgangskode);

            if (foundUser != null)
            {
                KundeLoggedIn = foundUser;
                return true;
            }
            else
            {
                return false;
            }            
        }

        public void LogoutKunde()
        {
            KundeLoggedIn = null;
        }
        
        
        public void removeKunde(Kunde kunde)
        {
            _Kunder.Remove(kunde);
        }

    }
}