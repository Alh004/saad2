using Fade_Lounge.Model;

namespace Fade_Lounge.ServicAs

{
    public interface IAdminRepository
    {       
        Admin? AdminLoggedIn { get; }

        void AddKundeAdm(Admin admin);
        bool CheckKundeAdm(string email, string adgangskode);
        void LogoutKundeAdm();
        void RemoveKundeAdm(Admin admin);
        Admin RemoveKundeAdm(int kundeNummer);
        Admin HentKunde(int kundeNummer);
    }
}